<?php
/**
 * MCCY Narrative functions and definitions
 *
 * @package MCCY
 * @subpackage Narrative
 * @since 1.0.0
 */

/**
 * Table of Contents:
 * Theme Support
 * Required Files
 * Register Styles
 * Register Scripts
 * Register Menus
 * Custom Logo
 * WP Body Open
 * Template Redirect
 */

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function mccy_narrative_theme_support() {

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	// Custom background color.
	add_theme_support(
		'custom-background',
		array(
			'default-color' => 'f5efe0',
		)
	);

	// Set content-width.
	global $content_width;
	if ( ! isset( $content_width ) ) {
		$content_width = 580;
	}

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );

	// Set post thumbnail size.
	set_post_thumbnail_size( 1200, 9999 );


	// Custom logo.
	$logo_width  = 120;
	$logo_height = 90;

	// If the retina setting is active, double the recommended width and height.
	if ( get_theme_mod( 'retina_logo', false ) ) {
		$logo_width  = floor( $logo_width * 2 );
		$logo_height = floor( $logo_height * 2 );
	}

	add_theme_support(
		'custom-logo',
		array(
			'height'      => $logo_height,
			'width'       => $logo_width,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support(
		'html5',
		array(
			'comment-form',
			'caption',
			'script',
			'style',
		)
	);

	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on MCCY Narrative, use a find and replace
	 * to change 'mccy-narrative' to the name of your theme in all the template files.
	 */
	load_theme_textdomain( 'mccy-narrative' );

	// Add support for full and wide align images.
	add_theme_support( 'align-wide' );

	/*
	 * Adds `async` and `defer` support for scripts registered or enqueued
	 * by the theme.
	 */
	$loader = new MCCY_Narrative_Script_Loader();
	add_filter( 'script_loader_tag', array( $loader, 'filter_script_loader_tag' ), 10, 2 );

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );
}

add_action( 'after_setup_theme', 'mccy_narrative_theme_support' );

/**
 * REQUIRED FILES
 * Include required files.
 */

require get_template_directory() . '/inc/template-tags.php';

// Handle Customizer settings.
require get_template_directory() . '/classes/class-mccy-narrative-customize.php';

// Custom script loader class.
require get_template_directory() . '/classes/class-mccy-narrative-script-loader.php';

// Default Editor.
require get_template_directory() . '/inc/default-editor.php';

// Init all class function
require get_template_directory() . '/classes/init.php';

/**
 * Register navigation menus uses wp_nav_menu in five places.
 */
function mccy_narrative_menus() {

	$locations = array(
		'main-menu'  => __( 'Main Menu', 'mccy-narrative' ),
	);

	register_nav_menus( $locations );
}

add_action( 'init', 'mccy_narrative_menus' );

/**
 * Get the information about the logo.
 *
 * @param string $html The HTML output from get_custom_logo (core function).
 *
 * @return string $html
 */
function mccy_narrative_get_custom_logo( $html ) {

	$logo_id = get_theme_mod( 'custom_logo' );

	if ( ! $logo_id ) {
		return $html;
	}

	$logo = wp_get_attachment_image_src( $logo_id, 'full' );

	if ( $logo ) {
		// For clarity.
		$logo_width  = esc_attr( $logo[1] );
		$logo_height = esc_attr( $logo[2] );

		// If the retina logo setting is active, reduce the width/height by half.
		if ( get_theme_mod( 'retina_logo', false ) ) {
			$logo_width  = floor( $logo_width / 2 );
			$logo_height = floor( $logo_height / 2 );

			$search = array(
				'/width=\"\d+\"/iU',
				'/height=\"\d+\"/iU',
			);

			$replace = array(
				"width=\"{$logo_width}\"",
				"height=\"{$logo_height}\"",
			);

			// Add a style attribute with the height, or append the height to the style attribute if the style attribute already exists.
			if ( strpos( $html, ' style=' ) === false ) {
				$search[]  = '/(src=)/';
				$replace[] = "style=\"height: {$logo_height}px;\" src=";
			} else {
				$search[]  = '/(style="[^"]*)/';
				$replace[] = "$1 height: {$logo_height}px;";
			}

			$html = preg_replace( $search, $replace, $html );

		}
	}

	return $html;

}

add_filter( 'get_custom_logo', 'mccy_narrative_get_custom_logo' );

if ( ! function_exists( 'wp_body_open' ) ) {

	/**
	 * Shim for wp_body_open, ensuring backwards compatibility with versions of WordPress older than 5.2.
	 */
	function wp_body_open() {
		do_action( 'wp_body_open' );
	}
}

/**
 * Template Redirect
 */
function mccy_narrative_template_redirect() {
  if ( is_category() || is_tax() || is_tag() || is_author() || is_attachment() ) {
    wp_redirect( home_url() );
    die;
  }
}
add_action( 'template_redirect', 'mccy_narrative_template_redirect' );

require get_template_directory() . '/inc/cleanup.php';
require get_template_directory() . '/inc/enqueue.php';

/**
 * Hide not use menu
 */
function remove_unused_menu()
{
 remove_menu_page( 'edit.php' ); 					//Post Menu
 remove_menu_page( 'upload.php' );				//Media Menu
 remove_menu_page( 'edit-comments.php' );	//Comment Menu
}
add_action( 'admin_menu', 'remove_unused_menu' );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function kyber_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Contact Info', 'kyber' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here to appear in your footer area.', 'kyber' ),
			'before_widget' => '',
			'after_widget'  => '',
			'before_title'  => '',
			'after_title'   => '',
		)
	);
	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Contact Form', 'kyber' ),
			'id'            => 'sidebar-3',
			'description'   => esc_html__( 'Add widgets here to appear in your footer area.', 'kyber' ),
			'before_widget' => '',
			'after_widget'  => '',
			'before_title'  => '',
			'after_title'   => '',
		)
	);
	register_sidebar(
		array(
			'name'          => esc_html__( 'Modal Contact Info', 'kyber' ),
			'id'            => 'sidebar-2',
			'description'   => esc_html__( 'Add widgets here to appear in your contact form.', 'kyber' ),
			'before_widget' => '',
			'after_widget'  => '',
			'before_title'  => '',
			'after_title'   => '',
		)
	);
}
add_action( 'widgets_init', 'kyber_widgets_init' );

/**
 * SVG support
 */
function cc_mime_types($mimes) {
	$mimes['svg'] = 'image/svg+xml';
	return $mimes;
 }
 add_filter('upload_mimes', 'cc_mime_types');

 /**
	*
  */
function kyber_get_menu_items( $parent_item = null ) {
	$locations = get_nav_menu_locations();
	if( $locations ) {
		$menu = wp_get_nav_menu_object( $locations[ 'main-menu' ] );
		if( $menu) {
			$menu_items = wp_get_nav_menu_items($menu->term_id);
			if ( $menu_items ) {
				$return_items = [];
				foreach ( $menu_items as $item ) {
					if ( (!$parent_item && !$item->menu_item_parent) || ($item->menu_item_parent == $parent_item->ID) ) {
						array_push($return_items, $item);
					}
				}
					return $return_items;
			}
		}
	}
	return null;
}

function kyber_get_main_menu_items() {
	return kyber_get_menu_items( null );
}

function kyber_get_main_menu_subitems( $parent_item ) {
	if( $parent_item ) {
		$sub_items = kyber_get_menu_items( $parent_item );
		if ( count( $sub_items ) > 0)
			return $sub_items;
	}
	return null;
}

function append_query_string( $url, $post ) {
	if ( 'service' == get_post_type( $post ) ) {
		$basename = basename( $url );
		return str_replace("/" . $basename . "/", "#" . $basename, $url);
	}
	return $url;
}
add_filter( 'post_type_link', 'append_query_string', 10, 2 );

//Re-order comments form
function kyber_comment_fields_custom_order( $fields ) {
    $comment_field = $fields['comment'];
    $author_field = $fields['author'];
    $email_field = $fields['email'];
    $url_field = $fields['url'];
    $cookies_field = $fields['cookies'];

    unset( $fields['comment'] );
    unset( $fields['author'] );
    unset( $fields['email'] );
    unset( $fields['url'] );
    unset( $fields['cookies'] );

    $fields['author'] = $author_field;
    $fields['email'] = $email_field;
    $fields['comment'] = $comment_field;

    return $fields;
}
add_filter( 'comment_form_fields', 'kyber_comment_fields_custom_order' );

function kyber_test_deploy(){
	return 'update on 202112301815';
}

//Register Post Type
function cptui_register_my_cpts_programmes() {

  /**
   * Post Type: Programmes
   */

  $labels = [
    "name" => __( "Programmes", "custom-post-type-ui" ),
    "singular_name" => __( "Programmes", "custom-post-type-ui" ),
  ];

  $args = [
    "label" => __( "Programmes", "custom-post-type-ui" ),
    "labels" => $labels,
    "description" => "",
    "public" => true,
    "publicly_queryable" => true,
    "show_ui" => true,
    "show_in_rest" => true,
    "rest_base" => "",
    "rest_controller_class" => "WP_REST_Posts_Controller",
    "has_archive" => false,
    "show_in_menu" => true,
    "show_in_nav_menus" => true,
    "delete_with_user" => false,
    "exclude_from_search" => false,
    "capability_type" => "post",
    "map_meta_cap" => true,
    "hierarchical" => false,
    "can_export" => false,
    "rewrite" => [ "slug" => "programmes", "with_front" => true ],
    "query_var" => true,
    "supports" => [ "title", "editor"],
    "show_in_graphql" => false,
  ];

  register_post_type( "programmes", $args );
}
add_action( 'init', 'cptui_register_my_cpts_programmes' );

function cptui_register_my_cpts_centre() {

  /**
   * Post Type: Centres.
   */

  $labels = [
    "name" => __( "Centres", "custom-post-type-ui" ),
    "singular_name" => __( "Centre", "custom-post-type-ui" ),
  ];

  $args = [
    "label" => __( "Centres", "custom-post-type-ui" ),
    "labels" => $labels,
    "description" => "",
    "public" => true,
    "publicly_queryable" => true,
    "show_ui" => true,
    "show_in_rest" => true,
    "rest_base" => "",
    "rest_controller_class" => "WP_REST_Posts_Controller",
    "has_archive" => false,
    "show_in_menu" => true,
    "show_in_nav_menus" => true,
    "delete_with_user" => false,
    "exclude_from_search" => false,
    "capability_type" => "post",
    "map_meta_cap" => true,
    "hierarchical" => false,
    "can_export" => false,
    "rewrite" => [ "slug" => "centre", "with_front" => true ],
    "query_var" => true,
    "supports" => [ "title", "editor", "thumbnail" ],
    "show_in_graphql" => false,
  ];

  register_post_type( "centre", $args );
}
add_action( 'init', 'cptui_register_my_cpts_centre' );

//Register Taxonomy
function cptui_register_my_taxes_centre_district() {

  /**
   * Taxonomy: Districts.
   */

  $labels = [
    "name" => __( "Districts", "custom-post-type-ui" ),
    "singular_name" => __( "District", "custom-post-type-ui" ),
  ];


  $args = [
    "label" => __( "Districts", "custom-post-type-ui" ),
    "labels" => $labels,
    "public" => true,
    "publicly_queryable" => true,
    "hierarchical" => false,
    "show_ui" => true,
    "show_in_menu" => true,
    "show_in_nav_menus" => true,
    "query_var" => true,
    "rewrite" => [ 'slug' => 'centre_district', 'with_front' => true, ],
    "show_admin_column" => false,
    "show_in_rest" => true,
    "show_tagcloud" => false,
    "rest_base" => "centre_district",
    "rest_controller_class" => "WP_REST_Terms_Controller",
    "show_in_quick_edit" => false,
    "sort" => false,
    "show_in_graphql" => false,
  ];
  register_taxonomy( "centre_district", [ "centre" ], $args );
}
add_action( 'init', 'cptui_register_my_taxes_centre_district' );

function cptui_register_my_taxes_centre_area() {

  /**
   * Taxonomy: Areas.
   */

  $labels = [
    "name" => __( "Areas", "custom-post-type-ui" ),
    "singular_name" => __( "Area", "custom-post-type-ui" ),
  ];


  $args = [
    "label" => __( "Areas", "custom-post-type-ui" ),
    "labels" => $labels,
    "public" => true,
    "publicly_queryable" => true,
    "hierarchical" => false,
    "show_ui" => true,
    "show_in_menu" => true,
    "show_in_nav_menus" => true,
    "query_var" => true,
    "rewrite" => [ 'slug' => 'centre_area', 'with_front' => true, ],
    "show_admin_column" => false,
    "show_in_rest" => true,
    "show_tagcloud" => false,
    "rest_base" => "centre_area",
    "rest_controller_class" => "WP_REST_Terms_Controller",
    "show_in_quick_edit" => false,
    "sort" => false,
    "show_in_graphql" => false,
  ];
  register_taxonomy( "centre_area", [ "centre" ], $args );
}
add_action( 'init', 'cptui_register_my_taxes_centre_area' );
