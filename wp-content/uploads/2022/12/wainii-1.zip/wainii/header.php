<?php
/**
 * The Kyberosc theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package KyberOSC
 */

?><!DOCTYPE html>
<html lang="en">
<!--include ../partials/head-->

<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="description" content="Latest technologies and software development techniques to build powerful and flexible solutions for companies around the world.">
	<title>Qualitative software development </title>
	<link rel="apple-touch-icon" sizes="180x180" href="img\favicon\apple-touch-icon.png">
	<link rel="icon" type="image/png" href="img\favicon\favicon-32x32.png" sizes="32x32">
	<link rel="icon" type="image/png" href="img\favicon\favicon-16x16.png" sizes="16x16">
	<link rel="mask-icon" href="img\favicon\safari-pinned-tab.svg" color="#5bbad5">
	<meta name="theme-color" content="#ffffff">
	<script>
		var ActionChat = "on";
	</script>
  <?php wp_head(); ?>
</head>

<body class="js-body" <?php body_class(); ?>>
<?php
  print_r('1111111111');
  $centre = get_posts([
    'post_type' => 'centre',
    'post_status' => 'publish',
    'numberposts' => -1
  ]);
  print_r( json_encode($centre) );
  wp_body_open();
?>
