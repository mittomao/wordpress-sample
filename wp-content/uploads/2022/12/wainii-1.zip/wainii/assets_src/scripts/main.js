$(function () {
  // Slick

  const $ourClientSlide = $('.js-our-client-slide');
  $ourClientSlide.not('.slick-initialized').slick({
    prevArrow:'.arrow-prev',
    nextArrow:'.arrow-next',
    dots:true,
    autoplay: true,
    autoplaySpeed: 3000,
    slidesToShow: 1,
    slidesToScroll: 1,
  })

  // Navigation js

  let lastscrolltop = 0;
  $(window).on('scroll', function () {
    if ($(window).scrollTop() > lastscrolltop) {
      $('.js-header-top').addClass('scrolled-hide');
    }
    else {
      $('.js-header-top').removeClass('scrolled-hide');
    }
    lastscrolltop = $(window).scrollTop();
  });

  $(window).scroll(function () {
    if ($(window).scrollTop() > 68) {
      $('.js-header-bottom').addClass('mini-header__background-color')
    } else {
      $('.js-header-bottom').removeClass('mini-header__background-color')
    }
  })

  $(".js-close-button").click(function () {
    $('.js-none').toggleClass('mini-header-none');
    $('.js-header').toggleClass('header-prevent-scroll');
  });

  const sectionIds = $('.navigation a.nav-link');

  $(window).scroll(function () {
    sectionIds.each(function () {
      const section = $(this).attr('href');
      const scrollPosition = $(window).scrollTop();
      const sectionTop = $(section).offset().top;
      const sectionBottom = sectionTop + $(section).outerHeight(true);

      if (scrollPosition >= sectionTop - 200 && scrollPosition < sectionBottom - 200) {
        $(this).addClass('active');
      } else {
        $(this).removeClass('active')
      }
    })
  });

  // Smooth scroll down js

  $(".navigation a, .masthead__scroll").on('click', function(event) {
    if (this.hash !== "") {
      event.preventDefault();
      let hash = this.hash;
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 800, function(){
        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });

  // Form contact js

  $(".wpcf7-form-control-wrap").change(function () {
    $('.wpcf7-not-valid-tip', this).hide();
  });

  const $contactusform = $("#contactusform");
  const $contactusform1 = $("#contactusform1");
  const $modalSuccess = $('.modal-success2');
  const $jsButtonTilt1 = $(".js-button-tilt1");
  const $jsButtonTilt2 = $(".js-button-tilt2");

  $contactusform.on( 'wpcf7mailsent', function( event ) {
    $contactusform.modal('hide');
    $modalSuccess.modal('show');
    setTimeout(function() {
      $modalSuccess.modal('hide');
    }, 4000);
  });

  $contactusform.on( 'wpcf7invalid', function( event ) {
    $jsButtonTilt2.addClass("button__animated");
    setTimeout(function() {
      $jsButtonTilt2.removeClass("button__animated");
    }, 500);
  });

  $contactusform1.on( 'wpcf7invalid', function( event ) {
    $jsButtonTilt1.addClass("button__animated");
    setTimeout(function() {
      $jsButtonTilt1.removeClass("button__animated");
    }, 500);
  });

  $contactusform1.on( 'wpcf7mailsent', function( event ) {
    $modalSuccess.modal('show');
    setTimeout(function() {
      $modalSuccess.modal('hide');
    }, 4000);
  });

  // service reverse

  const $service = $('.services');

  $service.each(function (i, item) {
    const $content = $(item).find('.services__content');

    if (i % 2 === 1) {
      $content.addClass('services__content--reverse');
    }
  });

});
