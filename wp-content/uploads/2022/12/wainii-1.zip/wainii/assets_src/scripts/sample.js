
$(document).ready(function() {
  var n = $("html, body")
    , c = $(".js-topline")
    , e = $(".js-header-top")
    , t = $(".js-mobile-panel")
    , u = $(".js-nav-trigger")
    , f = "nav__link-current"
    , a = "icon-active"
    , s = "overflow-hidden"
    , r = document.createElement("div")
    , v = e.height()
    , p = 50;
  r.style.overflowY = "scroll",
    r.style.width = "50px",
    r.style.height = "50px",
    r.style.visibility = "hidden",
    document.body.appendChild(r);
  var o = r.offsetWidth - r.clientWidth;
  document.body.removeChild(r),
    $("[data-scrollbar-y=hidden]").css("marginRight", -o + "px");
  var i = location.pathname.split("/")
    , l = i[i.length - 1];

  $("nav").each(function() {
    $(this).find("a").each(function() {
      $(this).attr("href") == l && ($(this).parent().hasClass("extra-nav") ? $(this).addClass("extra-nav__link_current") : $(this).addClass(f))
    })
  }),

    $(window).scroll(function() {
      var a, s, e, t, n, r, o, i, l, d = $(document).scrollTop();
      t = d,
        n = $(".header"),
        r = $(".js-header-fixed"),
        o = "is-fixed",
        i = "header-scrolled",
        l = "is-undefined",
        768 < $(window).width() ? (150 < t ? r.addClass(i) : r.removeClass(i),
          a = t,
        (e = $(".js-feature-section")).length && (e.each(function(e, t) {
          var n = $(t).offset();
          a >= n.top - v - p && (s = "#" + $(t).attr("id"))
        }),
          $(".js-submenu").removeClass(f),
          $('a.js-submenu[href="' + s + '"]').addClass(f))) : 150 < t ? (u.addClass(l),
          c.addClass(o),
          n.css("height", "1px")) : (u.removeClass(l),
          c.removeClass(o),
          n.css("height", "0"))
    });
  var d = !1
    , h = $(".js-body")
    , m = $(".js-main")
    , C = $(".js-footer");
  u.click(function() {
    return !d && (d = !0,
      document.addEventListener("touchmove", function(e) {
        u.hasClass(a) && e.preventDefault()
      }, !1),
      u.each(function() {
        $(this).toggleClass(a)
      }),
      h.toggleClass(s),
      t.fadeToggle(300, "swing", function() {
        d = !1
      }),
      !0)
  }),
    $(window).resize(function() {
      1023 < window.innerWidth && u.hasClass(a) && (u.removeClass(a),
        C.fadeOut(200),
        m.fadeOut(200),
        t.fadeOut(300),
        h.removeClass(s))
    });
  var g = $(".arrow__up");
  function _(e) {
    var t = $(e).offset().top;
    n.animate({
      scrollTop: t - 64
    }, 600)
  }
  $(window).scroll(function() {
    120 < $(window).scrollTop() ? g.fadeIn() : g.fadeOut()
  }),
    $(document).on("click", ".arrow__up", function(e) {
      e.preventDefault(),
        n.animate({
          scrollTop: 0
        }, "500")
    }),
    $(".js-scroll").on("click", function(e) {
      e.preventDefault(),
        $(".js-scroll").each(function() {
          $(this).removeClass(f)
        }),
        $(this).addClass(f);
      var t = $(this).attr("href");
      _($(t))
    }),
    setTimeout(function() {
      if (location.hash) {
        window.scrollTo(0, 0);
        var e = location.hash.split("#");
        _($("#" + e[1]))
      }
    }, 1)
});
