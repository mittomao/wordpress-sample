<?php
/**
 * Custom template tags for this theme.
 *
 * @package MCCY
 * @subpackage Narrative
 * @since 1.0.0
 */

/**
 * Logo
 * Secondary Logo
 */

/**
 * Displays the site logo
 *
 * @param array   $args Arguments for displaying the site logo either as an image or text.
 *
 * @return string $html Compiled HTML based on our arguments.
 */
function mccy_narrative_site_logo( $args = array(), $echo = true ) 
{
	$logo_id = get_theme_mod( 'custom_logo' );
	$image = wp_get_attachment_image_src( $logo_id , 'full' );
	
	if ( !empty ($image) && !empty ($image[0]) ) {
		$html = '<img src="'.esc_url($image[0]).'" alt=""/>';
	

		if ( ! $echo ) {
			return $html ?? '';
		}
		
		echo $html;
	}
	return '';
}

/**
 * Displays the secondary logo
 *
 * @param array   $args Arguments for displaying the site logo either as an image or text.
 *
 * @return string $html Compiled HTML based on our arguments.
 */
function mccy_narrative_secondary_logo( $args = array(), $echo = true ) 
{
	$logo_id = get_theme_mod( 'secondary_logo' );
	$image = wp_get_attachment_image_src( $logo_id , 'full' );
	
	if ( !empty ($image) && !empty ($image[0]) ) {
		$html = '<img src="'.esc_url($image[0]).'" alt=""/>';
	

		if ( ! $echo ) {
			return $html ?? '';
		}
		
		echo $html;
	}
	return '';
}

/**
 * Displays the secondary logo site url
 */
function mccy_narrative_secondary_logo_url() 
{
	$url = get_theme_mod( 'secondary_logo_url' );
	return $url ?? '';
}