<?php
/**
* Plugin Name: Add general function
* Version: 1.0
* Author: TribalDDBSG
**/

add_filter("use_block_editor_for_post_type", "mccy_narrative_disable_gutenberg_editor");
function mccy_narrative_disable_gutenberg_editor()
{
  return false;
}