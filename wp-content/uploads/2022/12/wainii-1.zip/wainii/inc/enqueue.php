<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! function_exists( 'mccy_narrative_register_scripts' ) ) {
	/**
	 * Load theme's JavaScript and CSS sources.
	 */
	function mccy_narrative_register_scripts()
	{
		// Get the theme data.
		$the_theme     = wp_get_theme();
		$theme_version = $the_theme->get( 'Version' );

		$wogaa_script = get_field('_mccy_narrative_theme_analytic_wogaa_url','option');
		if( !empty( $wogaa_script ) ) {
			wp_enqueue_script( 'wogaa-js', $wogaa_script, array(), $theme_version );
		}

		wp_enqueue_style( 'kyber-website-styles', get_template_directory_uri() . '/assets/styles/styles.css', [], filemtime(get_template_directory() . '/assets/styles/styles.css'), 'all' );

//     wp_enqueue_script( 'mccy-narrative-analytics-js', get_template_directory_uri() . '/assets/scripts/analytics/analytics.js', [], filemtime(get_template_directory() . '/assets/scripts/analytics/analytics.js'), false );
    wp_enqueue_script( 'kyber-website-jquery', get_template_directory_uri() . '/assets/scripts/jquery.min.js', [], filemtime(get_template_directory() . '/assets/scripts/jquery.min.js'), true );
    wp_enqueue_script( 'kyber-website-js', get_template_directory_uri() . '/assets/scripts/scripts.js', [], filemtime(get_template_directory() . '/assets/scripts/scripts.js'), true );
//     wp_enqueue_script( 'mccy-narrative-webshim-js', get_template_directory_uri() . '/assets/scripts/webshim/polyfiller.js', [], filemtime(get_template_directory() . '/assets/scripts/webshim/polyfiller.js'), true );

    if ( basename( get_page_template() ) == "page-submission.php" || basename( get_page_template() ) == "page-explore.php" || basename( get_single_template() ) == "single-story.php") {
      wp_enqueue_script( 'narrative-recaptcha-js', 'https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit', true );
    }

		$url = admin_url( 'admin-ajax.php' );
		wp_add_inline_script( 'mccy-narrative-js',
			'window.mccy_narrative = window.mccy_narrative || {}; window.mccy_narrative.api = window.mccy_narrative.api || {}; window.mccy_narrative.api.ajax_url = \''.$url.'\';',
			'before'
		);
	}
}
add_action( 'wp_enqueue_scripts', 'mccy_narrative_register_scripts', 1);
