<?php
/**
 * The template for displaying the 404 template in the MCCY Narrative.
 *
 * @package MCCY
 * @subpackage Narrative
 * @since 1.0.0
 */

get_header();
?>

<main class="section section--singular js-page-not-found" role="main">
  <div class="container">

    <div class="section-inner thin error404-content">

      <h1 class="entry-title"><?php _e( 'Page Not Found', 'mccy-narrative' ); ?></h1>

      <div class="intro-text"><p><?php _e( 'The page you were looking for could not be found. It might have been removed, renamed, or did not exist in the first place.', 'mccy-narrative' ); ?></p></div>

    </div><!-- .section-inner -->

  </div>
</main><!-- #site-content -->

<?php
get_footer();
