const gulp = require('gulp'),
      log = require('fancy-log');
      c = require('ansi-colors'),
      browserSync = require('browser-sync').create(),
      reload = browserSync.reload;
      filter = require('gulp-filter'),
      touch = require('gulp-touch-cmd'),
      plugin = require('gulp-load-plugins')(),
      autoprefixer = require('autoprefixer'),
      moment = require('moment'),
      zip = require('gulp-zip'),
      del = require( 'del' ),
      sass = require('gulp-sass')(require('sass')),
      strip = require('gulp-strip-comments');

const LOCAL_URL = 'http://localhost/';

const BULMA = 'node_modules/bulma';
const NODE_MODULES = 'node_modules';

const SOURCE = {
  scripts : [
    NODE_MODULES + '/bootstrap/dist/js/bootstrap.bundle.min.js',
    NODE_MODULES + '/jquery.cookie/jquery.cookie.js',
    // NODE_MODULES + '/moment/moment.js',
    // NODE_MODULES + '/select2/dist/js/**/*.js',
    NODE_MODULES + '/slick-carousel/slick/slick.min.js',
    'assets_src/scripts/main.js'
  ],
  scriptsBase: NODE_MODULES + '/jquery/dist/jquery.min.js',
  webshim: NODE_MODULES + '/webshim/js-webshim/minified/**/*',
  styles: './assets_src/styles/**/*.scss',
  images: './assets_src/images/**/*',
  statics: NODE_MODULES +'/slick-carousel/slick/ajax-loader.gif',
  fonts: [
    NODE_MODULES +'/slick-carousel/slick/fonts/**/*',
    './assets_src/assets/fonts/**/*',
  ],
  php: '**/*.php'
};

const ASSETS = {
	styles: './assets/styles/',
	scripts: './assets/scripts/',
	webshim: './assets/scripts/webshim',
  statics: './assets/assets/statics/',
  fonts: './assets/assets/fonts/',
	images: './assets/images/',
	all: './assets/'
};

const JSHINT_CONFIG = {
	'node': true,
	'globals': {
		'document': true,
		'window': true,
		'jQuery': true,
		'$': true
	}
};

function scripts() {
  // Use a custom filter so we only lint custom JS
  const CUSTOMFILTER = filter(ASSETS.scripts + 'js/**/*.js', {restore: true});

  return gulp.src(SOURCE.scripts)
		.pipe(plugin.plumber(function(error) {
        log.error(c.bold.red(error.message));
        this.emit('end');
    }))
		.pipe(plugin.sourcemaps.init())
		.pipe(plugin.babel())
    .pipe(plugin.eslint({ fix: true }))
    .pipe(plugin.eslint.format())
    .pipe(plugin.eslint.failAfterError())
		.pipe(plugin.concat('scripts.js'))
    .pipe(strip())
		.pipe(plugin.sourcemaps.write('.')) // Creates sourcemap for minified JS
		.pipe(gulp.dest(ASSETS.scripts))
    .pipe(touch());
}

function scriptsBase() {
  return gulp.src(SOURCE.scriptsBase)
    .pipe(gulp.dest(ASSETS.scripts));
}

function libs() {
  return gulp.src(SOURCE.webshim)
		.pipe(plugin.plumber(function(error) {
        log.error(c.bold.red(error.message));
        this.emit('end');
    }))
		.pipe(gulp.dest(ASSETS.webshim));
}

function styles () {
  return gulp.src(SOURCE.styles)
		.pipe(plugin.plumber(function(error) {
            log.error(c.bold.red(error.message));
            this.emit('end');
        }))
		.pipe(plugin.sourcemaps.init())
		.pipe(sass({ outputStyle: 'expanded' }))
    .pipe(gulp.dest(ASSETS.styles))
		.pipe(plugin.postcss([ autoprefixer() ]))
		.pipe(plugin.cssnano({
      safe: true,
      minifyFontValues: {removeQuotes: false},
      discardComments: {removeAll: true,}
    }))
		.pipe(plugin.sourcemaps.write('.'))
		.pipe(gulp.dest(ASSETS.styles))
    .pipe(touch());
    // .pipe(browserSync.stream());
}

function images () {
  return gulp.src(SOURCE.images)
		//.pipe(plugin.imagemin())
		.pipe(gulp.dest(ASSETS.images))
    .pipe(touch());
}

function statics () {
  return gulp.src(SOURCE.statics)
		.pipe(gulp.dest(ASSETS.statics))
    .pipe(touch());
}

function fonts () {
  return gulp.src(SOURCE.fonts)
		.pipe(gulp.dest(ASSETS.fonts))
    .pipe(touch());
}

function reload(done) {
  browserSync.reload();
  done();
}

function serve(done) {
  browserSync.init({
    files: [
      SOURCE.php,
    ],
    proxy: {
      target: LOCAL_URL,
    },
    port: 8890
  });
  done();
}

function watch() {
  gulp.watch(SOURCE.styles, gulp.series('styles'));
  gulp.watch(SOURCE.scripts, gulp.series('scripts'));
  gulp.watch(SOURCE.images, gulp.series('images'));
}

const PATHS = {
  root: '../../',
  sass: 'assets/styles/src',
  scripts: 'assets/scripts/src',
  images: 'assets/images/src',
  node: 'node_modules',
  dist: 'dist',
};

// Deleting any file inside the /dist folder
function clean_dist() {
  return del( [PATHS.dist + '/**'] );
}

// Copies the files to the /dist folder for distribution as simple theme
function dist () {
  return gulp.src( [
      '**/*',
      '!' + PATHS.node + '/**',
      '!' + PATHS.node,
      '!' + PATHS.dist + '/**',
      '!' + PATHS.dist,
      '!' + PATHS.images + '/**',
      '!' + PATHS.images,
      '!' + PATHS.sass + '/**',
      '!' + PATHS.sass,
      '!' + PATHS.scripts + '/**',
      '!' + PATHS.scripts,
      '!assets/scripts/scripts.js.map',
      '!assets/styles/styles.css.map',
      '!.babelrc',
      '!package.json',
      '!package-lock.json',
      '!gulpfile.js'
    ], { 'buffer': true } )
    .pipe( gulp.dest( PATHS.dist ) );
}

// Deleting any file inside the .cwp-package folder
function clean_cwp_package() {
	return del( ['../../.cwp-package'], { force:true } );
}

function cwp_code() {
	return gulp.src( 'dist/**/*' )
		.pipe( gulp.dest( PATHS.root + '.cwp-package/Website/wp-content/themes/mccy-narrative' ) );
}


function cwp_config_staging() {
	return gulp.src( '../../config/staging/**/*' )
		.pipe( gulp.dest( PATHS.root + '.cwp-package/Config' ) );
}

function cwp_config_prod() {
	return gulp.src( '../../config/prod/**/*' )
		.pipe( gulp.dest( PATHS.root + '.cwp-package/Config' ) );
}

function cwp_plugins() {
	return gulp.src( [
		PATHS.root + 'plugins/**/*',
		'!../../plugins/hello.php',
		'!../../plugins/index.php',
		'!../../plugins/.gitkeep',
		'!../../plugins/akismet',
		'!../../plugins/akismet/**',
		'!**/.DS_Store'
	] )
	.pipe( gulp.dest( PATHS.root + '.cwp-package/Website/wp-content/plugins' ) );
}

function cwp_zip_config() {
	let timestamp = moment().format('YYYY-MM-DD_hh-mm-ss');
	return gulp.src( PATHS.root + '.cwp-package/**/*')
        .pipe(zip('cwp-config-'+timestamp+'.zip'))
		.pipe(gulp.dest(PATHS.root));
};


function cwp_zip_code() {
	let timestamp = moment().format('YYYY-MM-DD_hh-mm-ss');
	return gulp.src( PATHS.root + '.cwp-package/**/*')
        .pipe(zip('cwp-code-'+timestamp+'.zip'))
		.pipe(gulp.dest(PATHS.root));
};

function cwp_zip_complete() {
	let timestamp = moment().format('YYYY-MM-DD_hh-mm-ss');
	return gulp.src( PATHS.root + '.cwp-package/**/*')
        .pipe(zip('cwp-complete-'+timestamp+'.zip'))
		.pipe(gulp.dest(PATHS.root));
}

const dev = gulp.series( styles, scriptsBase, scripts, libs, images, statics, fonts, watch);
const build = gulp.series( styles, scriptsBase, scripts, libs, images, statics, fonts);
const cwp_config_staging_package = gulp.series( clean_cwp_package, clean_dist, dist, cwp_config_staging, cwp_zip_config);
const cwp_config_prod_package = gulp.series( clean_cwp_package, clean_dist, dist, cwp_config_prod, cwp_zip_config);
const cwp_code_package = gulp.series( clean_cwp_package, clean_dist, dist, cwp_code, cwp_zip_code);
const cwp_code_staging_package = gulp.series( clean_cwp_package, clean_dist, dist, cwp_code, cwp_config_staging, cwp_zip_code);
const cwp_code_prod_package = gulp.series( clean_cwp_package, clean_dist, dist, cwp_code, cwp_config_prod, cwp_zip_code);
const cwp_complete_staging_package = gulp.series( clean_cwp_package, clean_dist, dist, cwp_code, cwp_plugins, cwp_config_staging, cwp_zip_complete);
const cwp_complete_prod_package = gulp.series( clean_cwp_package, clean_dist, dist, cwp_code, cwp_plugins, cwp_config_prod, cwp_zip_complete);
const cwp_complete_package = gulp.series( clean_cwp_package, clean_dist, dist, cwp_code, cwp_plugins,cwp_zip_complete);
exports.default = dev;
exports.build = build;
exports.cwp_code_package = cwp_code_package;
exports.cwp_code_staging_package = cwp_code_staging_package;
exports.cwp_code_prod_package = cwp_code_prod_package;
exports.cwp_complete_package = cwp_complete_package;
exports.cwp_config_staging_package = cwp_config_staging_package;
exports.cwp_config_prod_package = cwp_config_prod_package;
exports.cwp_complete_staging_package = cwp_complete_staging_package;
exports.cwp_complete_prod_package = cwp_complete_prod_package;
exports.styles = styles;
exports.scripts = scripts;
exports.images = images;
