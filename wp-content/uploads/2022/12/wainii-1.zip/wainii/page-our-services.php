<?php
/*
 * Template Name: Our Services
 */
get_header(); ?>
  <?php
  get_template_part( 'template-parts/mini-navigation' );
  ?>
<main class="section section--singular js-sharing-page" role="main">
  <?php
    get_template_part( 'template-parts/masthead' );
  ?>

<div class="mt-negative-3-spacer">
  <div class="container">
    <?php
      $args = array(
        'post_type' => 'service',
        'posts_per_page' => -1,
      );
      $loop = new WP_Query( $args );
      while ( $loop->have_posts() ) : $loop->the_post();
        get_template_part( 'template-parts/services', get_post_type() );
      endwhile;

      wp_reset_postdata();
    ?>
  </div>
</div>
</main>
<?php
get_footer();?>
