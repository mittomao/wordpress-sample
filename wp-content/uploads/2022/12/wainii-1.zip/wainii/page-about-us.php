<?php
/*
 * Template Name: About us
 */
get_header(); ?>
  <?php
  get_template_part( 'template-parts/mini-navigation' );
  ?>
<main class="section section--singular js-sharing-page" role="main">
  <?php
  get_template_part( 'template-parts/masthead' );
  ?>
  <div class="mt-negative-3-spacer">
      <div class="container">
        <?php
        get_template_part( 'template-parts/features' );
        get_template_part( 'template-parts/locations' );
        get_template_part( 'template-parts/technologies' );
        ?>
      </div>
  </div>
</main>
<?php
get_footer();?>
