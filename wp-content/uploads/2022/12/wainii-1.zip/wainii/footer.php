<?php
/**
 * The template for displaying the footer
 *
 * Contains the opening of the #site-footer div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package KyberOSC
 * @since 1.0.0
 */

?>
      <footer class="footer">
        <div class="container">
          <div class="container-small">
            <div class="footer__container pb-component pt-component">
              <div class="footer__contact">
                <div class="footer__contact-text" id="footer_contact">Contact us</div>
              </div>
              <div class="footer__content">
                <div class="footer__info">
                  <?php if ( is_active_sidebar( 'sidebar-1' )  ) : ?>
                    <div class="widget-area" role="complementary">
                      <?php dynamic_sidebar( 'sidebar-1' ); ?>
                    </div>
                  <?php endif; ?>
                </div>
                <div class="footer__form">
                  <?php if ( is_active_sidebar( 'sidebar-3' )  ) : ?>
                      <div class="widget-area" role="complementary">
                        <?php dynamic_sidebar( 'sidebar-3' ); ?>
                      </div>
                    <?php endif; ?>
                </div>
              </div>
            </div>
          </div>
          </div>
          <div class="footer__copyright">
             <div class="container-small">
               <div class="footer__copyright-text">© Copyright <?php echo date("Y"); ?> KyberOSC, Inc. All Rights Reserved</div>
             </div>
          </div>
          <!-- Contact Form Dialog Start-->
          <div class="modal fade popup" id="contactusform" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
              <div class="modal-content popup__container">
                <div class="modal-header border-line-none">
                    <button type="button" id="myButton" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
              <div class="popup__section">
                <?php if ( is_active_sidebar( 'sidebar-2' )  ) : ?>
                  <div class="widget-area" role="complementary">
                    <?php dynamic_sidebar( 'sidebar-2' ); ?>
                  </div>
                <?php endif; ?>
              </div>
                </div>
              </div>
            </div>
          </div>

          <div class="modal fade js-modal-success2 modal-success2" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                          <div class="modal-body modal-success2__body">
                              <div class="icon-check-circle"></div>
                              <h3>Thank you!</h3>
                              <p>We have received your message and will contact you soon!</p>
                          </div>
                    </div>
                </div>
          </div>
      </footer>
    </div><!-- #page -->

    <?php wp_footer(); ?>
  </body>
</html>
