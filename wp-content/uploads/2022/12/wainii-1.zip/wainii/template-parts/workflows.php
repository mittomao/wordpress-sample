<div class="features mb-component-small">
      <div class="features__outer">
        <div class="container-small">
          <div class="row features__wrap pb-component pt-component">
            <div class="col-md-6 col-sm-12">
                <div class="features__column padd-xs-0">
                  <div class="features__icon-box">
                    <span class="icon-check-circle"></span>
                  </div>
                  <h3 class="features__title"><?php the_field('workflows_title'); ?></h3>
                  <?php if( get_field('workflows_subtitle') ): ?>
                    <p class="features__text"><?php the_field('workflows_subtitle'); ?></p>
                  <?php endif; ?>
                  <?php if( have_rows('workflows_descriptions') ): ?>
                    <ul class="features__describe">
                      <?php while( have_rows('workflows_descriptions') ): the_row(); ?>
                        <li class="features__text">
                          <span class="icon-check-circle"></span>
                          <span class="highlight-text"><?php the_sub_field('workflows_description_title'); ?>: </span>
                          <span><?php the_sub_field('workflows_description_content'); ?></span>
                        </li>
                      <?php endwhile; ?>
                    </ul>
                  <?php endif; ?>
                </div>
                <?php
                $link = get_field('workflows_button');
                if( $link ):
                  $link_url = $link['url'];
                  $link_title = $link['title'];
                  $link_target = $link['target'] ? $link['target'] : '_self';
                ?>
                  <a href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>" class="button features__button"
                    data-toggle="modal" data-target="#contactusform"
                  ><?php echo esc_html( $link_title ); ?></a>
                <?php endif; ?>
            </div>

            <div class="col-md-6 col-sm-12">
              <div class="features__column">
                <div class="features__list">
                  <ul class="timeline">
                    <?php while( have_rows('workflows_items') ): the_row(); ?>
                      <li class="timeline__item">
                        <p class="timeline__title"><?php the_sub_field('workflows_item_title'); ?></p>
                        <?php echo str_replace('<p>', '<p class="timeline__text">', get_sub_field( 'workflows_item_description' ) ); ?>
                      </li>
                    <?php endwhile; ?>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<!-- #site-content -->
