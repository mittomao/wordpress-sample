<div class="features mb-component-small">
  <div class="features__outer">
    <div class="container-small">
      <div class="features__wrap row pb-component pt-component">
        <div class="col-md-6 col-sm-12">
          <div class="features__column padd-xs-0">
            <div class="features__icon-box">
              <span class="icon-check-circle"></span>
            </div>
            <h3 class="features__title"><?php the_field('feature_title'); ?></h3>
            <?php if( get_field('feature_description') ): ?>
              <p class="features__text"><?php the_field('feature_description'); ?></p>
            <?php endif; ?>
          </div>
        </div>

        <div class="col-md-6 col-sm-12">
          <div class="features__column">
            <div class="features__list">
              <?php if( have_rows('feature_items') ): ?>
                <?php while( have_rows('feature_items') ): the_row(); ?>
                  <div class="features__item feature">
                    <p class="feature__title"><?php the_sub_field('feature_item_title'); ?></p>
                    <div class="feature__columns">
                      <div class="feature__col">
                        <p class="feature__text"><?php the_sub_field('feature_item_description'); ?></p>
                      </div>
                      <div class="feature__col">
                        <div class="feature__count line">
                          <span class="icon-check-circle"></span>
                        </div>
                      </div>
                    </div>
                  </div>
                <?php endwhile; ?>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- #site-content -->
