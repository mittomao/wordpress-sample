<div class="customers pt-component pb-component">
        <div class="container-small">
          <div class="technology">
            <div class="technology__title">
              <div class="row">
                <div class="col-md-4">
                  <h3 class="technology__title-name"><?php the_field('technologies_title'); ?></h3>
                </div>
                <div class="col-md-8">
                  <?php if( get_field('technologies_description') ): ?>
                    <p class="technology__title-text"><?php the_field('technologies_description'); ?></p>
                  <?php endif; ?>
                </div>
              </div>
            </div>

            <?php
            $tags = get_field('technologies_tag');
            if( $tags ): ?>
              <div class="skills">
                <?php foreach( $tags as $tag ): ?>
                  <div class="skills__wrapper">
                    <div class="skill img-grayscale">
                      <div class="skill__item-top">
                        <div class="skill__item-title">
                          <?php if( get_field('technology_tag_image', $tag) ): ?>
                            <img src="<?php the_field('technology_tag_image', $tag); ?>" alt="PHP">
                          <?php endif; ?>
                        </div>
                      </div>
                      <div class="skill__item-bottom">
                        <span class="skill__item-link"><?php echo esc_html( $tag->name ); ?></span>
                      </div>
                    </div>
                  </div>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
          </div>
        </div>
    </div>
<!-- #site-content -->
