    <div class="modal fade popup" id="contactusform" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
      <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content popup__container">
          <div class="modal-header border-line-none">
              <button type="button" id="myButton" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
          </div>
          <div class="modal-body">
        <div class="popup__section">
          <div class="popup__title">Let's get started!</div>
          <form class="form" method="post" id="contactform2">
            <input type="hidden" name="crumb" value="tAlxz8peVHHGW3R2srQxojeJ0RTPFA0yjJ_bj1NhauT">
            <div class="form__contacts">
              <div class="form__contacts-item form__contacts-item--phone icon-phone_iphone">
                <a href="tel:(+84)2466559845" class="form__contacts-link js-dynamic-phone">(+84)2466559845</a>
              </div>
              <div class="form__contacts-divider"></div>
              <div class="form__contacts-item">
                    <span class="form__contacts-img icon-mail"></span>
                <a href="mailto:sales@kyberosc.com" class="form__contacts-link">sales@kyberosc.com</a>
              </div>
            </div>
            <div class="form__row">
              <div data-error-message="Please enter a valid information" class="control">
                <input type="text" placeholder="Name" id="name" name="name" class="control__field" maxlength="500" required
                 oninvalid="this.setCustomValidity('Please enter a valid information')" onchange="this.setCustomValidity('')"  />
              </div>
            </div>
            <div class="form__row">
              <div data-error-message="Please enter a valid information" class="control">
                 <input type="email" id="email" required placeholder="Email" class="control__field js-required"
                 oninvalid="this.setCustomValidity('Please enter a valid information')" onchange="this.setCustomValidity('')"  />
              </div>
            </div>

            <div class="form__row">
              <div data-error-message="Please enter a valid information" class="control js-control-auto-size">
                <textarea placeholder="Comments" name="message" class="control__field textarea textarea--sm" data-word-count="wc_popup_feedback" maxlength="6000" required></textarea>
              </div>
            </div>
            <div class="form__row form__address">
              <span class="form__contacts-link icon-man-icon"></span>
              <div class="form__contacts-address">
                <p><span>Office 1:</span> 4 floor, 229 Quang Trung Street, Ha Dong, Ha Noi</p>
                <p><span>Office 2:</span> B14-D21 Cau Giay New Urban Area, Dich Vong Hau Street, Cau Giay, Ha Noi</p>
              </div>
            </div>
            <button type="submit" class="button button--margin js-button-tilt2">Send</button>
          </form>
        </div>
          </div>
        </div>
      </div>
    </div>

     <div class="modal fade js-modal-success2 modal-success2" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered" role="document">
               <div class="modal-content">
                    <div class="modal-body modal-success2__body">
                         <div class="icon-check-circle"></div>
                         <h3>Thank you!</h3>
                         <p>We have received your message and will contact you soon!</p>
                    </div>
               </div>
          </div>
     </div>
