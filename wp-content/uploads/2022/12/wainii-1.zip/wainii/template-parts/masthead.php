   <?php
     global $post;
     $post_slug = $post->post_name;
     $class_mb = '';
     if ($post_slug == 'home') {
     $class_mb = 'mb-component';
     }
   ?>
<div class="masthead <?php echo $class_mb ?>" style="background-image: url('<?php the_field('masthead_image'); ?>')">
  <div class="container">
    <div class="container-small masthead__wrap">
      <?php if( get_field('masthead_title') ): ?>
        <div class="masthead__title"><?php the_field('masthead_title'); ?><span>.</span></div>
      <?php endif; ?>
      <?php if( get_field('masthead_subtitle') ): ?>
      <div class="masthead__desc"><?php the_field('masthead_subtitle'); ?></div>
      <?php endif; ?>
    </div>
   <?php
     global $post;
     $post_slug = $post->post_name;
     if ($post_slug == 'home') :
   ?>
      <a class="masthead__scroll" href="#expertise-area">
        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 36" class="arrows">
          <path d="M0,20l15,16l15-16" class="a1"></path>
          <path d="M0,10l15,16l15-16" class="a2"></path>
          <path d="M0,0l15,16L30,0" class="a3"></path>
        </svg>
      </a>
    <?php endif; ?>
  </div>
</div>
<!-- #site-content -->

