<div class="our-clients">
  <div class="our-clients__outer">
    <div class="container-small" style="position:relative">
      <div class="row our-clients__wrap pb-component pt-component">
              <div class="our-clients__heading">
                <div class="our-clients__title"><?php the_field('clients_title'); ?></div>
                <div class="our-clients__desc"><?php the_field('clients_subtitle'); ?></div>
              </div>
              <div class="arrow-prev">
                <span class="icon-arrow_back_ios"></span>
              </div>
              <div class="slides js-our-client-slide">
                <!--      slides 1-->
                <?php if( have_rows('clients_items') ): ?>
                  <?php while( have_rows('clients_items') ): the_row(); ?>
                    <div class="our-clients__slides">
                      <div class="slides-info">
                        <div class="slides-info__header">
                          <img class="slides-info__image" src="<?php the_sub_field('clients_item_logo'); ?>" alt="">
                          <div class="slides-info__name">
                            <div class="slides-info__name-title"><a href="<?php the_sub_field('clients_item_link'); ?>"><?php the_sub_field('clients_item_name'); ?></a></div>
                            <?php if( get_sub_field('clients_item_field') ): ?>
                              <div class="slides-info__name-desc"><?php the_sub_field('clients_item_field'); ?></div>
                            <?php endif; ?>
                          </div>
                        </div>
                        <div class="slides-info__desc">
                          <?php the_sub_field('clients_item_description'); ?>
                        </div>
                      </div>

                      <div class="slides-delegate">
                        <div class="slides-delegate__avatar">
                          <?php if( get_sub_field('clients_item_representative_image') ): ?>
                            <img src="<?php the_sub_field('clients_item_representative_image'); ?>" alt="">
                          <?php else : ?>
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/avatar-empty.png" alt="">
                          <?php endif; ?>
                        </div>
                        <div class="slides-delegate__info">
                          <div class="slides-delegate__name"><?php the_sub_field('clients_item_representative_name'); ?></div>
                          <?php if( get_sub_field('clients_item_representative_position') ): ?>
                            <div class="slides-delegate__position"><?php the_sub_field('clients_item_representative_position'); ?></div>
                          <?php endif; ?>
                        </div>
                      </div>
                    </div>
                  <?php endwhile; ?>
                <?php endif; ?>
              </div>
              <div class="arrow-next">
                <span class="icon-arrow_forward_ios"></span>
              </div>
      </div>
    </div>
  </div>
</div>
<!-- #site-content -->
