<div class="companies mb-component" id="expertise-area">
  <div class="container-small companies__cont">
    <div class="companies__title">
      <h2 class="companies__title-heading"><?php the_field('area_of_experties_title'); ?></h2>
      <div class="companies__title-text"><?php the_field('area_of_experties_subtitle'); ?></div>
    </div>

    <div class="companies__columns">
      <div class="row">
        <?php
          $services = get_field('area_of_experties_services');
          $techPerService = get_field('area_of_experties_number_of_technologies');
          if( $services ):
          foreach( $services as $service ):
          ?>
            <div class="col-md-4 col-sm-12 mb-component-small">
              <div class="company">
                <a href="<?php echo get_permalink($service->ID); ?>" class="company__portrait" style="background-image: url('<?php the_field('service_image', $service); ?>');"></a>
                <div class="company__content">
                  <div class="company__content-wrap">
                    <h4 class="company__title"><a href="<?php echo get_permalink($service->ID); ?>"><?php echo get_the_title($service); ?></a></h4>
                    <div class="company__text"><?php the_field('service_description', $service); ?></div>
                  </div>
                  <div class="company__footer">
                    <?php
                      $tags = get_field('service_tags', $service);
                      $techCount = 0;
                      if( $tags ): ?>
                      <ul class="company__footer-popular-images">
                        <?php foreach( $tags as $tag ):
                          if ( $techCount < $techPerService) :
                            $techCount++; ?>
                          <li class="img-grayscale">
                            <?php if( get_field('technology_tag_image', $tag) ): ?>
                              <img src="<?php the_field('technology_tag_image', $tag); ?>" alt="<?php echo esc_html( $tag->name ); ?>" title="<?php echo esc_html( $tag->name ); ?>">
                            <?php endif; ?>
                          </li>
                        <?php
                          endif;
                          endforeach; ?>
                      </ul>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
            </div>
          <?php
          endforeach;
          endif;
          ?>
      </div>
    </div>
  </div>
</div>

<!-- #site-content -->
