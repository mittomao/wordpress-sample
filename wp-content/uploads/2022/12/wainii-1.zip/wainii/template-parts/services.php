<div class="services mb-component-small" id="<?php echo get_post_field( 'post_name', get_the_ID() ); ?>">
  <div class="services__wrap">
    <div class="container-small">
      <div class="services__content pt-component pb-component">
        <?php if( get_field('service_image') ): ?>
          <div class="services__content-img"><img src="<?php the_field('service_image'); ?>" alt=""></div>
        <?php endif; ?>
        <div class="services__content-text">
          <div class="services__content-title"><?php the_title(); ?></div>
          <div class="services__content-desc"><?php the_content(); ?></div>
        </div>
      </div>
      <?php
        $tags = get_field('service_tags');
        if( $tags ): ?>
        <div class="services__skills pb-component ">
          <?php foreach( $tags as $tag ): ?>
            <div class="services__skills-wrap">
              <div class="services__language">
                <div class="services__language-box">
                  <div class="services__language-img">
                    <?php if( get_field('technology_tag_image', $tag) ): ?>
                      <img src="<?php the_field('technology_tag_image', $tag); ?>" alt="">
                    <?php endif; ?>
                  </div>
                </div>
                <div class="services__language-text"><?php echo esc_html( $tag->name ); ?></div>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
