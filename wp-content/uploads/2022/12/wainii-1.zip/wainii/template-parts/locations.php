<div class="location pt-component pb-component">
  <div class="location__wrap">
    <div class="container-small">
      <div class="location__title"><?php the_field('location_title'); ?></div>
      <?php if( get_field('location_subtitle') ): ?>
        <div class="location__title-desc"><?php the_field('location_subtitle'); ?></div>
      <?php endif; ?>
    </div>
    <?php if( have_rows('locations_location') ): ?>
      <div class="location__content">
        <?php while( have_rows('locations_location') ): the_row(); ?>
          <?php if( get_sub_field('location_image') ): ?>
            <div class="location__image" style="background-image: url('<?php the_sub_field('location_image'); ?>')"></div>
          <?php endif; ?>
          <div class="container-small">
            <div class="location__content-box pb-component">
              <?php if( get_sub_field('location_city') && get_sub_field('location_country') ): ?>
                <div class="location__city"><?php the_sub_field('location_city'); ?><span><?php the_sub_field('location_country'); ?></span></div>
              <?php endif; ?>
              <?php if( get_sub_field('location_address') ): ?>
                <div class="location__address"><?php the_sub_field('location_address'); ?></div>
              <?php endif; ?>
            </div>
          </div>
        <?php endwhile; ?>
      </div>
    <?php endif; ?>
  </div>
</div>
<!-- #site-content -->
