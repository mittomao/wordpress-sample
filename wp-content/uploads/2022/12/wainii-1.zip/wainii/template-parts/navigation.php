<div class="header js-header">
  <div class="container">
    <nav class="navbar navbar-expand-md navbar-dark">
      <div class="header__logo">
        <a href="<?php echo home_url(); ?>" class="header__logo-link header__logo-link--white">
              <img src="<?php echo esc_url( wp_get_attachment_image_src( get_theme_mod( 'custom_logo' ), 'full' )[0] ); ?>" class="header__logo-img">
            </a>
      </div>

      <button class="navbar-toggler js-close-button collapsed" data-toggle="collapse" data-target="#navbarMenu">
        <span></span>
        <span></span>
        <span></span>
      </button>
      <div class="header__shape"></div>

      <div class="collapse navbar-collapse" id="navbarMenu">
        <?php
        $menu_items = kyber_get_main_menu_items();
        $current_page = get_queried_object_id();
        if ( $menu_items ) :
        ?>
          <ul class="navbar-nav mobile-nav">
            <?php foreach( $menu_items as $item ):
              $sub_items = kyber_get_main_menu_subitems($item);
              ?>
                <li class="nav-item">
                  <?php if ( $sub_items ) : ?>
                    <div class="dropdown">
                        <a
                          href="<?php echo $item->url ?>"
                          class="nav-link nav-link-space dropdown__btn nav-link--text <?php echo ($item->object_id == $current_page) ? "nav-link-current" : "" ?>"
                          data-toggle="header__dropdown">
                            <?php echo $item->title ?>
                        </a>
                        <div class="dropdown__content">
                          <?php foreach( $sub_items as $sub_item ): ?>
                            <a class='dropdown__content-link nav-link-space' href="<?php echo $sub_item->url ?>"><?php echo $sub_item->title ?></a>
                          <?php endforeach; ?>
                        </div>
                    </div>
                  <?php else: ?>
                    <a
                      href="<?php echo $item->url ?>"
                      <?php echo in_array("launch-contact-modal", $item->classes)? "data-toggle=\"modal\" data-target=\"#contactusform\"":"" ?>
                      class="nav-link nav-link-space <?php echo ($item->object_id == $current_page) ? "nav-link-current" : ""?>">
                        <?php echo $item->title ?>
                    </a>
                  <?php endif; ?>
                </li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      </div>
     </nav>
   </div>
</div>
