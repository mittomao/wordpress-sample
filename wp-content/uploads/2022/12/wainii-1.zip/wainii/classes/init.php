<?php
define( 'MCCY_NARRATIVE_BASE_DIR', dirname( __FILE__ ) );

if ( function_exists( 'spl_autoload_register' ) )
{
  spl_autoload_register( 'mccy_narrative_autoloader' );
}

/**
 * Extention autoloader
 *
 * @param string $class_name Class name to load.
 */
function mccy_narrative_autoloader( $class_name )
{
  if ( false !== strpos( $class_name, 'MCCY_Narrative' ) ) {
    $class_name = str_replace( 'MCCY_Narrative\\','',$class_name );
    $class_file = strtolower( str_replace( '_', '-', $class_name ) );

    $data_class = explode( '\\', $class_file );
    if ( ! empty( $data_class ) ) {
      $last_index = count( $data_class ) - 1;
    }
    $class_file = implode( '/', $data_class );

    $filename = MCCY_NARRATIVE_BASE_DIR . '/' . $class_file . '.php';

    if ( !empty( $filename ) && file_exists( $filename ) ) {
      require_once( $filename );
    }
  }
}

function mccy_narrative_classes_init()
{
  MCCY_Narrative\Acf::instance();
  MCCY_Narrative\Options::instance();
  MCCY_Narrative\Options\Analytic::instance();
  MCCY_Narrative\Options\Blacklisted::instance();
  MCCY_Narrative\Options\Recaptcha::instance();
  MCCY_Narrative\Options\Proxy::instance();
  MCCY_Narrative\Options\Comment::instance();

  // og
  MCCY_Narrative\Og::instance();
}

add_action( 'after_setup_theme', 'mccy_narrative_classes_init' );

add_filter( 'rest_authentication_errors', function( $result ) {
  // If a previous authentication check was applied,
  // pass that result along without modification.
  if ( true === $result || is_wp_error( $result ) ) {
      return $result;
  }

  // // No authentication has been performed yet.
  // // Return an error if user is not logged in.
  // if ( ! is_user_logged_in() ) {
  //     return new WP_Error(
  //         'rest_not_logged_in',
  //         __( 'You are not currently logged in.' ),
  //         array( 'status' => 401 )
  //     );
  // }

  // Our custom authentication check should have no effect
  // on logged-in requests
  return $result;
});

