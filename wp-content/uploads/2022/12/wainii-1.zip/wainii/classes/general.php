<?php
/**
 * Custom code for general function.
 *
 * @package MCCY
 * @subpackage Narrative
 * @since 1.0.0
 */

namespace MCCY_Narrative;

if ( class_exists( 'MCCY_Narrative\General' ) ) {
  return;
}

/**
 * General
 */
class General 
{

  public static function strip_domain( $url )
  {
    if ( substr($url,0,4) != "http" ) return $url;
    $url = str_replace("http://","",$url);
    $url = str_replace("https://","",$url);
    $data = explode("/",$url);
    if ( !empty ($data) && !empty ($data[0] ) ) {
      $url = str_replace($data[0],"",$url);
    }
    return $url;
  }
  
  public static function is_valid_file_mine( $file, $mines, $exts = [] )
  {
    $mimetype = mime_content_type($file['tmp_name']);
    if( ! in_array( $mimetype, $mines)  ) {
      return false;
    }

    if (  !empty ( $exts ) ) {
      $filename = $file['name'];
      $ext = pathinfo($filename, PATHINFO_EXTENSION);
      if( ! in_array( $ext, $exts)  ) {
        return false;
      }
    }

    if ( ( $ext == "jpg" || $ext == "jpeg" ) && ( $mimetype == 'image/jpeg' || $mimetype == 'image/jpg' ) ) {
      return true;
    }
    if ( $ext == "png" && $mimetype == 'image/png' ) {
      return true;
    }
    if ( $ext == "mp3" && $mimetype == 'audio/mpeg' ) {
      return true;
    }
    if ( $ext == "mp4" && $mimetype == 'video/mp4' ) {
      return true;
    }
    
    return false;
  }

  public static function is_valid_file_size( $file )
  {
    if( $file['size'] > 10485760 ) {
      return false;
    }
    return true;
  }

  
	public static function get_post_taxonomy ($id, $category, $args=[], $all = false) 
	{
		$cats = wp_get_post_terms($id, $category, $args);
		if ( is_wp_error($cats) ) return ;
		if ( $all ) {
			return $cats;
		}
		if ( !empty ( $cats ) && !empty ( $cats[0] )) return $cats[0];
		return ;
	}

	public static function get_post_taxonomy_name ($id, $category, $all = false) 
	{
		return self::get_post_taxonomy($id, $category, ['fields'=>'names'], $all);
	}

	public static function get_post_taxonomy_id ($id, $category, $all = false)
	{
		return self::get_post_taxonomy($id, $category, ['fields'=>'ids'], $all);
					
	}

}
