<?php
/**
 * Proxy.
 *
 * @package MCCY
 * @subpackage Narrative
 * @since 1.0.0
 */

namespace MCCY_Narrative;

if ( class_exists( 'MCCY_Narrative\Proxy' ) ) {
	return;
}

/**
 * Proxy
 */
class Proxy 
{
  /**
	 * Is proxy enable
	 */
  public static function is_enable () 
  {
    return get_option('mccy_narrative_proxy_enable') == 1 ? true : false;
  }

  /**
	 * Get Proxy Info
	 */
  public static function get_info ()
  {
    return [
      'address' => get_option('mccy_narrative_proxy_address'),
      'port' => get_option('mccy_narrative_proxy_port'),
      'user' => get_option('mccy_narrative_proxy_user'),
      'secret' => get_option('mccy_narrative_proxy_secret'),
    ];
  }
}