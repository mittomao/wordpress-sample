<?php
/**
 * Customizer settings for this theme.
 *
 * @package MCCY
 * @subpackage Narrative
 * @since 1.0.0
 */

if ( ! class_exists( 'MCCY_Narrative_Customize' ) ) {
	/**
	 * CUSTOMIZER SETTINGS
	 */
	class MCCY_Narrative_Customize {

		/**
		 * Register customizer options.
		 *
		 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
		 */
		public static function register( $wp_customize ) 
		{
		
			// site logo
			$wp_customize->selective_refresh->add_partial(
				'custom_logo',
				array(
					'selector'        => '.header-titles [class*=site-]:not(.site-description)',
					'render_callback' => 'mccy_narrative_customize_partial_site_logo',
				)
			);

			// secondary logo
			$wp_customize->selective_refresh->add_partial(
				'secondary_logo',
				array(
					'selector'        => '.header-titles [class*=site-]:not(.site-description)',
					'render_callback' => 'mccy_narrative_customize_partial_secondary_logo',
				)
			);

			$wp_customize->add_setting(
				'secondary_logo',
				[
					'capability'        => 'edit_theme_options',
					'transport' => 'refresh',
					'sanitize_callback' => 'absint'
				]
			);

			$wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'secondary_logo',
			array(
				 'label' => __( 'Secondary Logo' ),
				 'description' => '',
				 'section' => 'title_tagline',
				 'flex_width' => true, // Optional. Default: false
				 'flex_height' => true, // Optional. Default: false
				 'width' => 400, // Optional. Default: 150
				 'height' => 400, // Optional. Default: 150
				 'button_labels' => array( // Optional.
						'select' => __( 'Select Secondary Logo' ),
						'change' => __( 'Change Secondary Logo' ),
						'remove' => __( 'Remove' ),
						'default' => __( 'Default' ),
						'placeholder' => __( 'No Image selected' ),
						'frame_title' => __( 'Select Image' ),
						'frame_button' => __( 'Choose Image' ),
				 )
			)
	 ) );

			// custom logo url
			$wp_customize->selective_refresh->add_partial('secondary_logo_url');

			$wp_customize->add_setting(
				'secondary_logo_url',
				[
					'capability'        => 'edit_theme_options',
					'transport' 				=> 'refresh',
					'sanitize_callback' => 'esc_url'
				]
			);
			
 
			$wp_customize->add_control( 'secondary_logo_url',
				[
					'label' => __( 'Secondary Logo Site Url' ),
					'description' => '',
					'section' => 'title_tagline',
					'priority' => 10, // Optional. Order priority to load the control. Default: 10
					'type' => 'text', // Can be either text, email, url, number, hidden, or date
					'capability' => 'edit_theme_options', // Optional. Default: 'edit_theme_options'
					'input_attrs' => [
							'class' => 'my-custom-class',
							'style' => 'border: 1px solid rebeccapurple',
							'placeholder' => __( 'Entar site url.' ),
					],
				]
			);

		}
		/**
		 * Sanitize select.
		 *
		 * @param string $input The input from the setting.
		 * @param object $setting The selected setting.
		 *
		 * @return string $input|$setting->default The input from the setting or the default setting.
		 */
		public static function sanitize_select( $input, $setting ) {
			$input   = sanitize_key( $input );
			$choices = $setting->manager->get_control( $setting->id )->choices;
			return ( array_key_exists( $input, $choices ) ? $input : $setting->default );
		}

		/**
		 * Sanitize boolean for checkbox.
		 *
		 * @param bool $checked Whether or not a box is checked.
		 *
		 * @return bool
		 */
		public static function sanitize_checkbox( $checked ) {
			return ( ( isset( $checked ) && true === $checked ) ? true : false );
		}

	}

	// Setup the Theme Customizer settings and controls.
	add_action( 'customize_register', array( 'mccy_narrative_Customize', 'register' ) );

}


if( ! function_exists( 'remove_unused_customizer' ) ){
	function remove_unused_customizer($wp_customize) {
		$wp_customize->remove_section( 'colors' );
		$wp_customize->remove_section( 'background_image' );
		$wp_customize->remove_section( 'static_front_page' );
		$wp_customize->remove_section( 'custom_css' );
		$wp_customize->remove_control( 'blogname' );
		$wp_customize->remove_control( 'blogdescription' );
	}
}
add_action( 'customize_register', 'remove_unused_customizer' );


if ( ! function_exists( 'mccy_narrative_customize_partial_site_logo' ) ) {
	/**
	 * Render the site logo for the selective refresh partial.
	 *
	 * Doing it this way so we don't have issues with `render_callback`'s arguments.
	 */
	function mccy_narrative_customize_partial_site_logo() {
		mccy_narrative_site_logo();
	}
}


if ( ! function_exists( 'mccy_narrative_customize_partial_secondary_logo' ) ) {
	/**
	 * Render the site logo for the selective refresh partial.
	 *
	 * Doing it this way so we don't have issues with `render_callback`'s arguments.
	 */
	function mccy_narrative_customize_partial_secondary_logo() {
		mccy_narrative_secondary_logo();
	}
}

