<?php
/** 
 * ACF json
 *
 * @package MCCY
 * @subpackage Narrative
 * @since 1.0.0
 */

namespace MCCY_Narrative;

if ( class_exists( 'MCCY_Narrative\Acf' ) ) {
	return;
}

/**
 * Create shortcode for news
 */
class Acf {
  
  /**
   * Component instance object
   *
   * @var $instance instance of Acf
   */
  protected static $instance;

  /**
   * Construct function
   */
  protected function __construct()
  {
    /* Don't do anything, needs to be initialized via instance() method */
  }

  /**
   * Clone function
   */
  private function __clone()
  {
    wp_die( "Please don't __clone" );
  }

  /**
   * Wakeup function
   */
  private function __wakeup()
  {
    wp_die( "Please don't __wakeup" );
  }

  /**
   * Get singleton instance of Acf
   *
   * Instantiates and sets up a new instance if needed, or returns the singleton
   *
   * @module Acf
   *
   * @return Acf singleton
   */
  public static function instance()
  {
    if ( ! isset( self::$instance ) ) {

      self::$instance = new Acf();
      self::$instance->init();
    }

    return self::$instance;
  }

  /**
   * Init function
   */
  public function init()
  {
    add_filter( 'acf/location/rule_types' , [ $this, 'add_rule_types' ]);
    add_filter( 'acf/location/rule_values/page_slug', [ $this, 'add_rule_values_page_slug' ] );
    add_filter( 'acf/location/rule_match/page_slug', [ $this, 'add_rule_match_page_slug' ], 10, 4 );
	}

  function add_rule_types( $choices ) 
  {
	  $choices['Page']['page_slug'] = 'Page Slug';

    return $choices;
  }
  
  function add_rule_values_page_slug( $choices ) 
  {
    $post_type = 'page';
    $posts = get_posts([
      'posts_per_page'          => -1,
      'post_type'               => 'page',
      'orderby'                 => 'menu_order title',
      'order'                   => 'ASC',
      'post_status'             => 'publish',
      'suppress_filters'        => false,
      'update_post_meta_cache'  => false,
    ]);
    
    if( $posts ) {

      // sort into hierachial order!
      if( is_post_type_hierarchical( $post_type ) ) {

        $posts = get_page_children( 0, $posts );
      }
      
      foreach( $posts as $page ) {
        
        $title = '';
        $ancestors = get_ancestors($page->ID, 'page');
        if($ancestors) {
          
          foreach($ancestors as $a) {
            
            $title .= '- ';
          }
        }
        
        $title .= apply_filters( 'the_title', $page->post_title, $page->ID );
        
        $choices[ $page->post_name ] = $title;
        
      }
    
    }
    
    return $choices;
  }

  function add_rule_match_page_slug( $match, $rule, $options, $field_group )
  {
    if( empty( $options['post_id'] ) ) {
      return false;
    }

    $page = get_post( $options['post_id'] );
    if( is_wp_error( $page ) ) {
      return false;
    }

    $slug = $page->post_name;
    
    if( 'page' !== $page->post_type ) {
      return false;
    }
    
    if( '==' == $rule['operator'] ) { 
      $match = ( $rule['value'] == $slug );
    } 
    elseif( '!=' == $rule['operator'] ) {
      $match = ( $rule['value'] !== $slug );
    }
    
    return $match;
  }


}
