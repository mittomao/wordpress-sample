<?php
/**
 * Upload File to Wordpress Media.
 *
 * @package MCCY
 * @subpackage Narrative
 * @since 1.0.0
 */

namespace MCCY_Narrative;

if ( class_exists( 'MCCY_Narrative\Upload' ) ) {
	return;
}

/**
 * Upload
 */
class Upload 
{
  public static function file ($file) 
  {

    require( ABSPATH . 'wp-load.php' );
    
    if( empty( $file ) ) return false;
    
    if( $file['error'] ) return false;
    
    if( $file['size'] > wp_max_upload_size() ) return false;
    
    $wp_upload_dir = wp_upload_dir();
    $path = $wp_upload_dir['path'] . '/' . $file['name'];
    $mime = mime_content_type( $file['tmp_name'] );
    
    $i = 1;
    while( file_exists( $path ) ) {
      $i++;
      $path = $wp_upload_dir['path'] . '/' . $i . '_' . $file['name'];
    }
    // looks like everything is OK
    if( move_uploaded_file( $file['tmp_name'], $path ) ) {
    
      $upload_id = wp_insert_attachment( array(
        'guid'           => $path, 
        'post_mime_type' => $mime,
        'post_title'     => preg_replace( '/\.[^.]+$/', '', $file['name'] ),
        'post_content'   => '',
        'post_status'    => 'inherit'
      ), $path );
    
      // wp_generate_attachment_metadata() won't work if you do not include this file
      require_once( ABSPATH . 'wp-admin/includes/image.php' );
      require_once( ABSPATH . 'wp-admin/includes/media.php' );

      // Generate and save the attachment metas into the database
      wp_update_attachment_metadata( $upload_id, wp_generate_attachment_metadata( $upload_id, $path ) );
      
      return [
        'path'=> $path,
        'id' => $upload_id
      ];
    }
    return false;
  }
}