<?php
/**
 * Option Page to themes.
 *
 * @package MCCY
 * @subpackage Narrative
 * @since 1.0.0
 */

namespace MCCY_Narrative;

if ( class_exists( 'MCCY_Narrative\Options' ) ) {
	return;
}

/**
 * Option Page - themes.
 */
class Options 
{  
  const _OPTION_THEME = 'theme-settings';
  
  /**
	 * Component instance object
	 *
	 * @var $instance instance of Options
	 */
  protected static $instance;
  
  /**
	 * Construct function
	 */
	protected function __construct() 
	{
		/* Don't do anything, needs to be initialized via instance() method */
  }
  
  /**
	 * Clone function
	 */
	private function __clone() 
	{
		wp_die( "Please don't __clone" );
	}

	/**
	 * Wakeup function
	 */
	private function __wakeup() 
	{
		wp_die( "Please don't __wakeup" );
	}

	/**
	 * Get singleton instance of Options
	 *
	 * Instantiates and sets up a new instance if needed, or returns the singleton
	 *
	 * @module Options
	 *
	 * @return Category singleton
	 */
  public static function instance() 
	{
		if ( ! isset( self::$instance ) ) {

			self::$instance = new Options();
			self::$instance->init();
		}

		return self::$instance;
  }
  
  /**
	 * Init function
	 */
	public function init() 
  {
    add_action( 'acf/init' , [ $this, 'register_option_page' ] );
  }
  
	/**
	 * Register Option Page
	 *
	 * @return void
	 */
  function register_option_page()
  {
     // Check function exists.
    if( !function_exists( 'acf_add_options_page' ) )
      return;

    // register options page.
    $option_page = acf_add_options_page(array(
      'page_title'    => __('Theme Settings'),
      'menu_title'    => __('Theme Settings'),
      'menu_slug'     => self::_OPTION_THEME,
      'capability'    => 'edit_posts',
      'redirect'      => true
    ));

  }
}