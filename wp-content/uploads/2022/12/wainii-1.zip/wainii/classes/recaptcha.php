<?php
/**
 * Google Recaptcha.
 *
 * @package MCCY
 * @subpackage Narrative
 * @since 1.0.0
 */

namespace MCCY_Narrative;

if ( class_exists( 'MCCY_Narrative\Recaptcha' ) ) {
	return;
}

/**
 * Google Recaptcha
 */
class Recaptcha 
{
  const _API_URL = 'https://www.google.com/recaptcha/api/siteverify';

  public static function validate( $token )
  {
    // call curl to POST request
    $ch = curl_init();
    if ( Proxy::is_enable() ) {
      $info = Proxy::get_info();
      if ( !empty ( $info ) ) {
        curl_setopt($ch, CURLOPT_PROXY, $info['address'].":".$info['port']);
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $info['user'].":".$info['secret']);
      }
    }
    curl_setopt($ch, CURLOPT_URL,self::_API_URL);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(array('secret' => self::get_secret_key(), 'response' => $token)));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    
    curl_close($ch);
    $arrResponse = json_decode($response, true);
    
    // verify the response
    if($arrResponse["success"] == '1' ) {
        return true;
    }
    return false;
  }

  public static function get_secret_key ()
  {
    $secret_key = get_field('_mccy_narrative_theme_recaptcha_secret_key','option');
    return $secret_key ?? '';
  }

  public static function get_site_key ()
  {
    $site_key = get_field('_mccy_narrative_theme_recaptcha_site_key','option');
    return $site_key ?? '';
  }
}