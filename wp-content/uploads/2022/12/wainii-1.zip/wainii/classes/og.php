<?php
/**
 * Og Page.
 *
 * @package MCCY
 * @subpackage Narrative
 * @since 1.0.0
 */

namespace MCCY_Narrative;

if ( class_exists( 'MCCY_Narrative\Og' ) ) {
  return;
}

/**
 * Og PAge.
 */
class Og
{  
  /**
   * Component instance object
   *
   * @var $instance instance of Og
   */
  protected static $instance;

  /**
  * Construct function
  */
  protected function __construct() 
  {
    /* Don't do anything, needs to be initialized via instance() method */
  }

  /**
  * Clone function
  */
  private function __clone() 
  {
    wp_die( "Please don't __clone" );
  }

  /**
  * Wakeup function
  */
  private function __wakeup() 
  {
    wp_die( "Please don't __wakeup" );
  }

  /**
  * Get singleton instance of Og
  *
  * Instantiates and sets up a new instance if needed, or returns the singleton
  *
  * @module Og
  *
  * @return Og singleton
  */
  public static function instance() 
  {
    if ( ! isset( self::$instance ) ) {

      self::$instance = new Og();
      self::$instance->init();
    }

    return self::$instance;
  }

  /**
  * Init function
  */
  public function init() 
  {
    add_action('wp_head', [ $this, 'opengraph' ] );

  }

  public function opengraph() {

    if( is_single() || is_page() ) {

      $post_id = get_queried_object_id();
      
      $url = get_permalink($post_id);
      $site_name = get_bloginfo('name');
      $title = get_field( '_mccy_narrative_story_title', $post_id );
      $description = trim( get_field( '_mccy_narrative_story_description', $post_id ) );
      if ( empty ($title ) ) {
        $title = "Stories Of Us";
      }
      if ( empty ($description ) ) {
        $description = "Stories that define us during COVID-19";
      }
      // update the image url
      $image = 'https://s3-ap-southeast-1.amazonaws.com/storiesofus.gov.sg/storiesofus.jpg';
    
      $locale = get_locale();
      // Twitter Card
      $author   = str_replace('@', '', get_the_author_meta('twitter'));	
  ?>
      <meta property="og:locale" content="<?php echo esc_attr($locale); ?>" />
      <meta property="og:type" content="article" />
      <meta property="og:title" content="<?php echo esc_attr($title); ?>" />
      <meta property="og:description" content="<?php echo esc_attr($description); ?>" />
      <meta property="og:url" content="<?php echo esc_url($url); ?>" />
      <meta property="og:site_name" content="<?php echo esc_attr($site_name); ?>" />			
      <?php	if($image):?>
        <meta property="og:image" content="<?php echo esc_url($image); ?>" />
        <meta property="og:image:width" content="1200" />
        <meta property="og:image:height" content="630" />
      <?php endif; ?>
      <meta name="twitter:card" content="summary" />
      <meta name="twitter:title" content="<?php echo esc_attr($title); ?>" />
      <meta name="twitter:description" value="<?php echo esc_attr($description); ?>" />
      <meta name="twitter:url" value="<?php echo  esc_url($url); ?>" />
      <?php	if($image):?>
        <meta property="twitter:image" content="<?php echo esc_url($image); ?>" />
      <?php endif; 
    }
  }

}