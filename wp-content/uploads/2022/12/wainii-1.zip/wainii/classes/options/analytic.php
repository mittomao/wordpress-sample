<?php
/**
 * Option Page to enter analytics config.
 *
 * @package MCCY
 * @subpackage Narrative
 * @since 1.0.0
 */

namespace MCCY_Narrative\Options;
use MCCY_Narrative\Options;

if ( class_exists( 'MCCY_Narrative\Options\Analytic' ) ) {
	return;
}

/**
 * Option Page to enter tracking config.
 */
class Analytic 
{
  const _OPTION_THEME_ANALYTIC = 'theme-analytic';

  /**
   * Component instance object
   *
   * @var $instance instance of Option - Analytics Config
   */
  protected static $instance;

  /**
   * Construct function
   */
  protected function __construct() 
  {
    /* Don't do anything, needs to be initialized via instance() method */
  }

  /**
   * Clone function
   */
  private function __clone() 
  {
    wp_die( "Please don't __clone" );
  }

  /**
   * Wakeup function
   */
  private function __wakeup() 
  {
    wp_die( "Please don't __wakeup" );
  }

  /**
   * Get singleton instance of Options Analytic
   *
   * Instantiates and sets up a new instance if needed, or returns the singleton
   *
   * @module Options
   *
   * @return Analytic singleton
   */
  public static function instance() 
  {
    if ( ! isset( self::$instance ) ) {

      self::$instance = new Analytic();
      self::$instance->init();
    }

    return self::$instance;
  }

  /**
   * Init function
   */
  public function init() 
  {
    add_action( 'acf/init' , [ $this, 'register_option_page' ] );
    add_action( 'acf/init' , [ $this, 'register_custom_meta' ] );
  }

  /**
   * Register Option Page
   *
   * @return void
   */
  function register_option_page()
  {
      // Check function exists.
    if( !function_exists( 'acf_add_options_page' ) )
      return;

    // register options page.
    acf_add_options_sub_page(array(
      'page_title' 	=> __('Analytics Config'),
      'menu_title'	=> __('Analytics Config'),
      'menu_slug'   => self::_OPTION_THEME_ANALYTIC,
      'parent_slug'	=> Options::_OPTION_THEME,
    ));

  }

  /**
   * Register Custom Meta for Option Page
   *
   * @return void
   */
  function register_custom_meta()
  {
      // Check function exists.
    if( !function_exists( 'acf_add_local_field_group' ) ) {
      return;
    }

    acf_add_local_field_group([
      'key' => 'mccy_narrative_theme_analytic_information',
      'title' => 'Analytics',
      'fields' => [
        [
          'key'   => 'mccy_narrative_theme_analytic_pixel_enable',
          'label' => 'Pixel Enable',
          'name'  => '_mccy_narrative_theme_analytic_pixel_enable',
          'type'  => 'true_false',
          'instructions' => '',
          'required' => 0,
          'conditional_logic' => 0,
          'wrapper' => [
            'width' => '',
            'class' => '',
            'id' => '',
          ],
          'default_value' => 0,
          'message' => '',
          'ui' => 0,
          'ui_on_text' => '',
          'ui_off_text' => ''
        ],
        [
          'key' => 'mccy_narrative_theme_analytic_wogaa_url',
          'label' => 'Wogaa Script Url',
          'name' => '_mccy_narrative_theme_analytic_wogaa_url',
          'type' => 'url',
          'instructions' => 'Enter wogaa script url.',
          'prefix' => '',
          'required' => 0,
          'conditional_logic' => 0,
          'wrapper' => [
            'width' => '',
            'class' => '',
            'id' => '',
          ],
          'default_value' => '',
          'placeholder' => '',
          'prepend' => '',
          'append' => '',
          'maxlength' => '',
          'rows' => '20',
          'readonly' => 0,
          'disabled' => 0,
        ],
        [
          'key' => 'mccy_narrative_theme_analytic_gtm_code',
          'label' => 'GTM Tracking ID',
          'name' => '_mccy_narrative_theme_analytic_gtm_code',
          'type' => 'text',
          'prefix' => '',
          'required' => 0,
          'conditional_logic' => 0,
          'wrapper' => [
            'width' => '',
            'class' => '',
            'id' => '',
          ],
          'default_value' => '',
          'placeholder' => '',
          'prepend' => '',
          'append' => '',
          'maxlength' => '',
          'rows' => '20',
          'readonly' => 0,
          'disabled' => 0,
        ],
        [
          'key' => 'mccy_narrative_theme_analytic_ga_code',
          'label' => 'GA Ttacking ID',
          'name' => '_mccy_narrative_theme_analytic_ga_code',
          'type' => 'text',
          'prefix' => '',
          'required' => 0,
          'conditional_logic' => 0,
          'wrapper' => [
            'width' => '',
            'class' => '',
            'id' => '',
          ],
          'default_value' => '',
          'placeholder' => '',
          'prepend' => '',
          'append' => '',
          'maxlength' => '',
          'rows' => '20',
          'readonly' => 0,
          'disabled' => 0,
        ]
      ],
      'location' => [
        [
          [
            'param' => 'options_page',
            'operator' => '==',
            'value' => self::_OPTION_THEME_ANALYTIC,
          ],
        ],
      ],
      'menu_order' => 0,
      'position' => 'normal',
      'style' => 'default',
      'label_placement' => 'left',
      'instruction_placement' => 'label',
      'hide_on_screen' => '',
    ]);
  }
}