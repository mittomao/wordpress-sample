<?php
/**
 * Option Page for Proxy setting.
 *
 * @package MCCY
 * @subpackage Narrative
 * @since 1.0.0
 */

namespace MCCY_Narrative\Options;
use MCCY_Narrative\Options;

if ( class_exists( 'MCCY_Narrative\Options\Proxy' ) ) {
	return;
}

/**
 * Option Page for Proxy setting.
 */
class Proxy 
{
  const _OPTION_THEME_PROXY = 'theme-proxy';

  /**
   * Component instance object
   *
   * @var $instance instance of Page
   */
  protected static $instance;

  /**
   * Construct function
   */
  protected function __construct() 
  {
    /* Don't do anything, needs to be initialized via instance() method */
  }

  /**
   * Clone function
   */
  private function __clone() 
  {
    wp_die( "Please don't __clone" );
  }

  /**
   * Wakeup function
   */
  private function __wakeup() 
  {
    wp_die( "Please don't __wakeup" );
  }

  /**
   * Get singleton instance of Options Proxy Setting
   *
   * Instantiates and sets up a new instance if needed, or returns the singleton
   *
   * @module Options
   *
   * @return Proxy singleton
   */
  public static function instance() 
  {
    if ( ! isset( self::$instance ) ) {

      self::$instance = new Proxy();
      self::$instance->init();
    }

    return self::$instance;
  }

  /**
   * Init function
   */
  public function init() 
  {
    // create custom plugin settings menu
    add_action('admin_menu', [ $this, 'create_menu' ] );
  }
  
  function create_menu() 
  {
    //create new top-level menu
    add_menu_page('Proxy Settings', 'Proxy Settings', 'administrator', self::_OPTION_THEME_PROXY, [$this, 'settings_page']);
  
    //call register settings function
    add_action( 'admin_init', [ $this, 'register_settings' ] );
  }
  
  
  function register_settings() 
  {
    //register our settings
    register_setting( self::_OPTION_THEME_PROXY, 'mccy_narrative_proxy_enable' );
    register_setting( self::_OPTION_THEME_PROXY, 'mccy_narrative_proxy_address' );
    register_setting( self::_OPTION_THEME_PROXY, 'mccy_narrative_proxy_port' );
    register_setting( self::_OPTION_THEME_PROXY, 'mccy_narrative_proxy_user' );
    register_setting( self::_OPTION_THEME_PROXY, 'mccy_narrative_proxy_secret', [ $this, 'save_proxy_secret' ] );
  }

  function save_proxy_secret ( $input ) 
  {
    if ( empty ( $input ) ) {
      $input = get_option('mccy_narrative_proxy_secret');
    }
    return $input;
  }
  
  function settings_page() 
  {
  ?>
  <div class="wrap">
  <h1>Proxy Setting</h1>
  
  <form method="post" action="options.php" autocomplete="off">
      <?php settings_fields( self::_OPTION_THEME_PROXY ); ?>
      <?php do_settings_sections( self::_OPTION_THEME_PROXY ); ?>
      <table class="form-table">
          <tr valign="top">
            <th scope="row">Enable Proxy</th>
            <td><input type="checkbox" name="mccy_narrative_proxy_enable" 
            <?php if ( get_option('mccy_narrative_proxy_enable') == 1 ) : ?>
              checked
            <?php endif; ?>
            value="1" /></td>
          </tr>
           
          <tr valign="top">
            <th scope="row">Proxy Address</th>
            <td><input type="text" name="mccy_narrative_proxy_address" value="<?php echo esc_attr( get_option('mccy_narrative_proxy_address') ); ?>" /></td>
          </tr>
          
          <tr valign="top">
            <th scope="row">Proxy Port</th>
            <td><input type="text" name="mccy_narrative_proxy_port" value="<?php echo esc_attr( get_option('mccy_narrative_proxy_port') ); ?>" /></td>
          </tr>

          <tr valign="top">
            <th scope="row">Proxy User</th>
            <td><input type="text" name="mccy_narrative_proxy_user" value="<?php echo esc_attr( get_option('mccy_narrative_proxy_user') ); ?>" autocomplete="off" /></td>
          </tr>

          <tr valign="top">
            <th scope="row">Proxy Secret</th>
            <td><input type="password" name="mccy_narrative_proxy_secret" value="" autocomplete="off" /><br />(*Only input the secret if different from prev one)</td>
          </tr>
      </table>
      
      <?php submit_button(); ?>
  
  </form>
  </div>
  <?php 
  }
  
}