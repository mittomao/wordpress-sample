<?php
/**
 * Option Page to enter comment config.
 *
 * @package MCCY
 * @subpackage Narrative
 * @since 1.0.0
 */

namespace MCCY_Narrative\Options;
use MCCY_Narrative\Options;

if ( class_exists( 'MCCY_Narrative\Options\Comment' ) ) {
	return;
}

/**
 * Option Page to enter tracking config.
 */
class Comment 
{
  const _OPTION_THEME_COMMENT = 'theme-comment';

  /**
   * Comment instance object
   *
   * @var $instance instance of Option - Comment Config
   */
  protected static $instance;

  /**
   * Construct function
   */
  protected function __construct() 
  {
    /* Don't do anything, needs to be initialized via instance() method */
  }

  /**
   * Clone function
   */
  private function __clone() 
  {
    wp_die( "Please don't __clone" );
  }

  /**
   * Wakeup function
   */
  private function __wakeup() 
  {
    wp_die( "Please don't __wakeup" );
  }

  /**
   * Get singleton instance of Options Comment
   *
   * Instantiates and sets up a new instance if needed, or returns the singleton
   *
   * @module Comment
   *
   * @return Comment singleton
   */
  public static function instance() 
  {
    if ( ! isset( self::$instance ) ) {

      self::$instance = new Comment();
      self::$instance->init();
    }

    return self::$instance;
  }

  /**
   * Init function
   */
  public function init() 
  {
    add_action( 'acf/init' , [ $this, 'register_option_page' ] );
    add_action( 'acf/init' , [ $this, 'register_custom_meta' ] );
  }

  /**
   * Register Option Page
   *
   * @return void
   */
  function register_option_page()
  {
      // Check function exists.
    if( !function_exists( 'acf_add_options_page' ) )
      return;

    // register options page.
    acf_add_options_sub_page(array(
      'page_title' 	=> __('Comment Config'),
      'menu_title'	=> __('Comment Config'),
      'menu_slug'   => self::_OPTION_THEME_COMMENT,
      'parent_slug'	=> Options::_OPTION_THEME,
    ));

  }

  /**
   * Register Custom Meta for Option Page - Comment
   *
   * @return void
   */
  function register_custom_meta()
  {
      // Check function exists.
    if( !function_exists( 'acf_add_local_field_group' ) ) {
      return;
    }

    acf_add_local_field_group([
      'key' => 'mccy_narrative_theme_comment_information',
      'title' => 'Comment',
      'fields' => [
        [
          'key' => 'mccy_narrative_theme_comment_list',
          'label' => 'Comments',
          'name' => '_mccy_narrative_theme_comment_list',
          'type' => 'repeater',
          'instructions' => '',
          'required' => 0,
          'conditional_logic' => 0,
          'wrapper' => array(
            'width' => '',
            'class' => '',
            'id' => '',
          ),
          'collapsed' => '',
          'min' => 1,
          'max' => 0,
          'layout' => 'table',
          'button_label' => '',
          'sub_fields' => [
            [
              'key' => 'mccy_narrative_theme_comment__item',
              'label' => 'Comment',
              'name' => '_mccy_narrative_theme_comment__item',
              'type' => 'text',
              'instructions' => '',
              'required' => 1,
              'conditional_logic' => 0,
              'wrapper' => [
                'width' => '',
                'class' => '',
                'id' => '',
              ],
              'default_value' => '',
              'placeholder' => '',
              'prepend' => '',
              'append' => '',
              'maxlength' => '',
            ],
          ],
        ],
      ],
      'location' => [
        [
          [
            'param' => 'options_page',
            'operator' => '==',
            'value' => self::_OPTION_THEME_COMMENT,
          ],
        ],
      ],
      'menu_order' => 0,
      'position' => 'normal',
      'style' => 'default',
      'label_placement' => 'left',
      'instruction_placement' => 'label',
      'hide_on_screen' => '',
    ]);
  }

  function getList ()
  {
    
    if( have_rows( '_mccy_narrative_theme_comment_list', 'option' ) ){
      // loop through the rows of data
      $count = 0;
      while ( have_rows( '_mccy_narrative_theme_comment_list', 'option' ) ) {
        the_row();
        $data[] = get_sub_field('_mccy_narrative_theme_comment__item');
      }
    }
    
    return $data ?? [];
  }
}