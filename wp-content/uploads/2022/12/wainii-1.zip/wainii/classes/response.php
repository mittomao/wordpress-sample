<?php
/**
 * Api Response.
 *
 * @package MCCY
 * @subpackage MCCY_Narrative
 * @since 1.0.0
 */

namespace MCCY_Narrative;

if ( class_exists( 'MCCY_Narrative\Response' ) ) {
	return;
}

/**
 * Custom Api Response
 */
class Response 
{
  
  const _STATUS_200 = 200;
  const _STATUS_400 = 400;
  const _STATUS_401 = 401;
  const _STATUS_403 = 403;
  const _STATUS_404 = 404;
  const _STATUS_405 = 405;
  const _STATUS_500 = 500;

  public $response = ['error' => ['message' => 'Bad request']];

  public static function message($response = array(), $error_code = self::_STATUS_200)
  {
    if ( $error_code == self::_STATUS_200 ) {
      wp_send_json_success( ! empty( $response ) ? $response : [ 'message' => esc_html__( 'No data', 'mccy-narrative' ) ] );
    }
    wp_send_json_error( $response, self::_STATUS_200 );
  }
}